function apretar () {
    alert ("Has fet clic")
}

function sumar(){
var num1 = 3;
var num2 = 2;
suma = num1 + num2;
alert("La suma es: "+suma);
}
