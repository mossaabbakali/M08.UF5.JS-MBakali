function veureMes () {

    var x = document.getElementById("mestext");
    x.className = "visible";

}