function Confirmarpass(form) {
    password1 = form.password1.value;
    password2 = form.password2.value;

    // Contrasenya no coincideix.	
     if (password1 != password2) {
        alert ("La contrasenya no coincideix...");
    }

    // Contrasenya si coincideix.
    else{
        alert("Contrasenya aceptada");
    }
}
